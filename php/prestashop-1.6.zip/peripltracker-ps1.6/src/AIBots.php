<?php

namespace PeriplTracker;

class AIBots
{
    private $data = [
        'Mozilla/5.0 (compatible; AI2Bot/1.0; +http://www.allenai.org/crawler)' => [
            'name' => 'AI2Bot',
            'type' => 'training'
        ],
        'Ai2Bot-Dolma (+https://www.allenai.org/crawler)' => [
            'name' => 'Ai2Bot-Dolma',
            'type' => 'training'
        ],
        'Mozilla/5.0 (compatible; anthropic-ai/1.0; +http://www.anthropic.com/bot.html)' => [
            'name' => 'anthropic-ai',
            'type' => 'training'
        ],
        'Mozilla/5.0 (compatible; Applebot-Extended/1.0; +http://www.apple.com/bot.html)' => [
            'name' => 'Applebot-Extended',
            'type' => 'training'
        ],
        'Mozilla/5.0 (compatible; Bytespider/1.0; +http://www.bytedance.com/bot.html)' => [
            'name' => 'Bytespider',
            'type' => 'training'
        ],
        'Mozilla/5.0 (compatible; CCBot/1.0; +http://www.commoncrawl.org/bot.html)' => [
            'name' => 'CCBot',
            'type' => 'training'
        ],
        'Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko; compatible; ClaudeBot/1.0; +claudebot@anthropic.com)' => [
            'name' => 'ClaudeBot',
            'type' => 'training'
        ],
        'Mozilla/5.0 (compatible; cohere-ai/1.0; +http://www.cohere.ai/bot.html)' => [
            'name' => 'cohere-ai',
            'type' => 'training'
        ],
        'Mozilla/5.0 (compatible; Google-Extended/1.0; +http://www.google.com/bot.html)' => [
            'name' => 'Google-Extended',
            'type' => 'training'
        ],
        'Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko); compatible; GPTBot/1.1; +https://openai.com/gptbot' => [
            'name' => 'GPTBot',
            'type' => 'training'
        ],
        'Mozilla/5.0 (compatible; ImagesiftBot; +imagesift.com)' => [
            'name' => 'ImagesiftBot',
            'type' => 'training'
        ],
        'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:72.0) Gecko/20100101 Firefox/72.0 (compatible; img2dataset; +https://github.com/rom1504/img2dataset)' => [
            'name' => 'img2dataset',
            'type' => 'training'
        ],
        'Mozilla/5.0 (compatible; meta-externalagent/1.1 (+https://developers.facebook.com/docs/sharing/webmasters/crawler))' => [
            'name' => 'meta-externalagent',
            'type' => 'training'
        ],
        'Mozilla/5.0 (compatible; omgili/1.0; +http://www.omgili.com/bot.html)' => [
            'name' => 'omgili',
            'type' => 'training'
        ],
        'Mozilla/5.0 (Macintosh; Intel Mac OS X 10\_10\_1) AppleWebKit/600.2.5 (KHTML\\, like Gecko) Version/8.0.2 Safari/600.2.5 (Amazonbot/0.1; +https://developer.amazon.com/support/amazonbot)' => ['name' => 'Amazonbot',
            'type' => 'instant'],
        'Mozilla/5.0 (compatible; Applebot/1.0; +http://www.apple.com/bot.html)' => [
            'name' => 'Applebot',
            'type' => 'instant'
        ],
        'Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko); compatible; ChatGPT-User/1.0; +https://openai.com/bot' => [
            'name' => 'ChatGPT-User',
            'type' => 'instant'
        ],
        'Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko); compatible; ChatGPT-User/2.0; +https://openai.com/bot' => [
            'name' => 'ChatGPT-User',
            'type' => 'instant'
        ],
        'Mozilla/5.0 (compatible; claude-web/1.0; +http://www.anthropic.com/bot.html)' => [
            'name' => 'Claude-Web',
            'type' => 'instant'
        ],
        'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 (.NET CLR 3.5.30729; Diffbot/0.1; +http://www.diffbot.com)' => [
            'name' => 'Diffbot',
            'type' => 'instant'
        ],
        'Mozilla/5.0 (compatible; DuckAssistBot/1.0; +http://www.duckduckgo.com/bot.html)' => [
            'name' => 'DuckAssistBot',
            'type' => 'instant'
        ],
        'Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko); compatible; OAI-SearchBot/1.0; +https://openai.com/searchbot' => [
            'name' => 'OAI-SearchBot',
            'type' => 'instant'
        ],
        'Perplexity-User/1.0 +https://perplexity.ai/perplexity-user' => [
            'name' => 'Perplexity-User',
            'type' => 'instant'
        ],
        'Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko; compatible; PerplexityBot/1.0; +https://perplexity.ai/perplexitybot)' => [
            'name' => 'PerplexityBot',
            'type' => 'instant'
        ],
        'Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko; compatible; MistralAI-User/1.0; +https://docs.mistral.ai/robots)' => [
            'name' => 'MistralAI-User',
            'type' => 'instant'
        ],
    ];

    public function getAll()
    {
        return $this->data;
    }
}
