<?php //modified by module sd_translate version 1.9.0 on Fri, 23 May 2025 10:47:44 +0200

global $_MODULE;
$_MODULE = array();
$_MODULE['<{peripltracker}prestashop>peripltracker_207852b06996bfbd85bfaee952d0f856'] = 'Suit les visites de pages par des bots IA et envoie les données en mode « fire and forget » à Peripl.';
$_MODULE['<{peripltracker}prestashop>peripltracker_876f23178c29dc2552c0b48bf23cd9bd'] = 'Êtes-vous sûr de vouloir désinstaller ?';
$_MODULE['<{peripltracker}prestashop>peripltracker_f8a28c39587288879aadfd498b7986dc'] = 'URL de l\'API invalide';
$_MODULE['<{peripltracker}prestashop>peripltracker_1f876f7209844136432cc880af5363f2'] = 'L\'identifiant de propriété est requis';
$_MODULE['<{peripltracker}prestashop>peripltracker_e81c116b7bad6d7cad5d3dfb52f127c3'] = 'Échec de la mise à jour des paramètres';
$_MODULE['<{peripltracker}prestashop>peripltracker_c888438d14855d7d96a2724ee9c306bd'] = 'Paramètres mis à jour';
$_MODULE['<{peripltracker}prestashop>peripltracker_f4f70727dc34561dfde1a3c529b6205c'] = 'Paramètres';
$_MODULE['<{peripltracker}prestashop>peripltracker_0ec3571a7d62fdbb38a63ad87b3f7600'] = 'URL de l\'API';
$_MODULE['<{peripltracker}prestashop>peripltracker_71937a5f6ce270047cca96804615e221'] = 'L\'URL à laquelle les données de suivi seront envoyées';
$_MODULE['<{peripltracker}prestashop>peripltracker_d57f0be56e6fb6932a1f2d0d8ef57c32'] = 'Identifiant de propriété';
$_MODULE['<{peripltracker}prestashop>peripltracker_91a255cecdea3d31a9d6c63ccc4cd204'] = 'Votre identifiant de propriété unique';
$_MODULE['<{peripltracker}prestashop>peripltracker_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';
