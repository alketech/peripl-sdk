<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

if (file_exists(__DIR__ . '/vendor/autoload.php')) {
    require_once dirname(__FILE__) . '/vendor/autoload.php';
}

class PeriplTracker extends Module
{
    const DEFAULT_ENDPOINT = 'https://collector-peripl.alketech.eu/crawl';

    public function __construct()
    {
        $this->name = 'peripltracker';
        $this->tab = 'analytics_stats';
        $this->author = 'Peripl and JB ROMAIN (realdev.fr)';
        $this->need_instance = 0;
        $this->version = '2.0.1';

        $this->bootstrap = true;
        parent::__construct();

        $this->displayName = $this->l('Peripl Tracker');
        $this->description = $this->l(
            'Tracks page visits by AI bots and sends data in fire and forget mode to Peripl.'
        );

        $this->ps_versions_compliancy = [
            'min' => '1.7.0',
            'max' => _PS_VERSION_
        ];
    }

    public function install()
    {
        return parent::install()
            && $this->registerHook('actionDispatcher')
            && Configuration::updateValue('PERIPL_ENDPOINT', self::DEFAULT_ENDPOINT);
    }
    public function uninstall()
    {
        return parent::uninstall()
            && Configuration::deleteByName('PERIPL_ENDPOINT')
            && Configuration::deleteByName('PERIPL_PROPERTY_ID');
    }

    public function getContent()
    {
        return $this->postProcess()
            . $this->renderForm();
    }

    private function postProcess()
    {
        $output = '';

        if (!Tools::isSubmit('submit' . $this->name)) {
            return $output;
        }

        $endpoint = Tools::getValue('PERIPL_ENDPOINT');
        $propertyId = Tools::getValue('PERIPL_PROPERTY_ID');

        if (!Validate::isAbsoluteUrl($endpoint)) {
            $output .= $this->displayError($this->l('Invalid API endpoint URL'));
        } elseif (empty($propertyId)) {
            $output .= $this->displayError($this->l('Property ID is required'));
        } elseif (!Configuration::updateValue('PERIPL_ENDPOINT', $endpoint)
                || !Configuration::updateValue('PERIPL_PROPERTY_ID', $propertyId)) {
            $output .= $this->displayConfirmation($this->l('Failed to update settings'));
        } else {
            $output .= $this->displayConfirmation($this->l('Settings updated'));
        }

        return $output;
    }

    private function renderForm()
    {
        $fieldsForm = [
            'form' => [
                'legend' => [
                    'title' => $this->l('Settings'),
                    'icon' => 'icon-cogs'
                ],
                'input' => [
                    [
                        'type' => 'text',
                        'label' => $this->l('API Endpoint URL'),
                        'name' => 'PERIPL_ENDPOINT',
                        'desc' => $this->l('The URL where tracking data will be sent'),
                        'required' => true
                    ],
                    [
                        'type' => 'text',
                        'label' => $this->l('Property ID'),
                        'name' => 'PERIPL_PROPERTY_ID',
                        'desc' => $this->l('Your unique property identifier'),
                        'required' => true
                    ]
                ],
                'submit' => [
                    'title' => $this->l('Save'),
                    'class' => 'btn btn-default pull-right'
                ]
            ],
        ];

        $helperForm = new HelperForm();
        $helperForm->show_toolbar = false;
        $helperForm->table = $this->table;
        $lang = new Language((int)Configuration::get('PS_LANG_DEFAULT'));
        $helperForm->default_form_language = $lang->id;
        $helperForm->allow_employee_form_lang = Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG') ? Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG') : 0;
        $helperForm->identifier = $this->identifier;
        $helperForm->submit_action = 'submit' . $this->name;
        $helperForm->currentIndex = $this->context->link->getAdminLink('AdminModules', false) . '&configure=' . $this->name . '&tab_module=' . $this->tab . '&module_name=' . $this->name;
        $helperForm->token = Tools::getAdminTokenLite('AdminModules');
        $helperForm->tpl_vars = [
            'fields_value' => [
                'PERIPL_ENDPOINT' => Configuration::get('PERIPL_ENDPOINT', self::DEFAULT_ENDPOINT),
                'PERIPL_PROPERTY_ID' => Configuration::get('PERIPL_PROPERTY_ID')
            ],
            'languages' => $this->context->controller->getLanguages(),
            'id_language' => $this->context->language->id
        ];

        return $helperForm->generateForm([$fieldsForm]);
    }

    public function hookActionDispatcher()
    {
        $endpoint = Configuration::get('PERIPL_ENDPOINT', self::DEFAULT_ENDPOINT);
        $propertyId = Configuration::get('PERIPL_PROPERTY_ID');
        if (!Validate::isAbsoluteUrl($endpoint) || empty($propertyId)) {
            return;
        }

        new PeriplTracker\PeriplSDK(
            $endpoint,
            $propertyId
        );
    }

    /**
     * Ce module n'utilise pas la nouvelle mécanique de traductions.
     *
     * @see https://devdocs.prestashop-project.org/8/modules/creation/module-translation/new-system/
     */
    public function isUsingNewTranslationSystem()
    {
        return false;
    }
}
