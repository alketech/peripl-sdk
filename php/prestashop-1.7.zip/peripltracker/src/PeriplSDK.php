<?php

namespace PeriplTracker;

use Context;
use PrestaShopLogger;
use Throwable;

class PeriplSDK
{
    public function __construct($endpoint, $propertyId)
    {
        register_shutdown_function([$this, 'periplSendTrackingBeforeShutdown'], $endpoint, $propertyId);
    }

    private function periplSendDataFireAndForget($endpoint, $data)
    {
        $streamContext = stream_context_create([
            'http' => [
                'method' => 'POST',
                'header' => 'Content-Type: application/json',
                'timeout' => 1,
                'ignore_errors' => true
            ]
        ]);
        if (_PS_MODE_DEV_) {
            PrestaShopLogger::addLog('Peripl Tracker: send data to ' . $endpoint, 1, null, null, null, true);
        }

        @file_get_contents($endpoint . '?' . http_build_query($data), false, $streamContext);
    }

    public function periplSendTrackingBeforeShutdown($endpoint, $propertyId)
    {
        $userAgent = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '';

        // Ajout sécurité JB Romain - Si en BO, on n'envoie pas les données
        // (car elle contiennent l'URL du BO qui et sensible)
        try {
            if (Context::getContext()->controller instanceof \AdminController) {
                return;
            }
        } catch (Throwable $e) {
            PrestaShopLogger::addLog('Peripl Tracker: Error in periplSendTrackingBeforeShutdown: ' . $e->getMessage(), 3, null, null, null, true);
        }

        // On ne track que si l'agent utilisateur est un bot
        if (!$this->isBotIdentifiedByUserAgent($userAgent)) {
            return;
        }

        $this->periplSendDataFireAndForget($endpoint, [
            'pu' => $this->getPageFullUrl(),
            'ua' => $userAgent,
            'et' => time(),
            'sc' => http_response_code() ?: 200,
            'prop' => $propertyId
        ]);
    }

    private function getPageFullUrl()
    {
        $host = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '';
        $uri = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';

        return 'https://' . $host . $uri;
    }

    private function isBotIdentifiedByUserAgent($userAgent)
    {
        foreach ((new AIBots())->getAll() as $botUserAgent => $botData) {
            if (stripos($userAgent, $botUserAgent) !== false) {
                return true;
            }
        }
        return false;
    }
}
