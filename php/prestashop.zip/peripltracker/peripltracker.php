<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

class PeriplTracker extends \Module
{
    private $endpoint;
    private $propertyId;

    public function __construct()
    {
        $this->name = 'peripltracker';
        $this->tab = 'analytics_stats';
        $this->version = '1.0.0';
        $this->author = 'Your Name';
        $this->need_instance = 0;
        $this->ps_versions_compliancy = array('min' => '1.6', 'max' => '1.6.99.99');
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->l('Peripl Tracker');
        $this->description = $this->l('Tracks page visits and sends data in fire and forget mode to an external endpoint.');
        $this->confirmUninstall = $this->l('Are you sure you want to uninstall?');

        // Configuration par défaut
        $this->endpoint = \Configuration::get('PERIPL_ENDPOINT', 'https://api.example.com/endpoint');
        $this->propertyId = \Configuration::get('PERIPL_PROPERTY_ID', 'PROPERTY_ID_DEFAULT');

        require_once(__DIR__ . '/sdk.php');

        // Enregistrer la fonction de shutdown dès la construction du module
        register_shutdown_function('periplSendTrackingBeforeShutdown', $this->endpoint, $this->propertyId);;
    }

    /**
     * Installation du module
     */
    public function install()
    {
        if (!parent::install() ||
            !$this->registerHook('displayHeader') ||
            !$this->registerHook('actionDispatcher') ||
            !\Configuration::updateValue('PERIPL_ENDPOINT', 'https://api.example.com/endpoint') ||
            !\Configuration::updateValue('PERIPL_PROPERTY_ID', 'PROPERTY_ID_DEFAULT')) {
            return false;
        }
        return true;
    }

    /**
     * Désinstallation du module
     */
    public function uninstall()
    {
        if (!parent::uninstall() ||
            !\Configuration::deleteByName('PERIPL_ENDPOINT') ||
            !\Configuration::deleteByName('PERIPL_PROPERTY_ID')) {
            return false;
        }
        return true;
    }

    /**
     * Configuration du module
     */
    public function getContent()
    {
        $output = '';

        if (\Tools::isSubmit('submit' . $this->name)) {
            $endpoint = \Tools::getValue('PERIPL_ENDPOINT');
            $propertyId = \Tools::getValue('PERIPL_PROPERTY_ID');

            // Validation de l'URL
            if (!\Validate::isUrl($endpoint)) {
                $output .= $this->displayError($this->l('Invalid API endpoint URL'));
            } elseif (empty($propertyId)) {
                $output .= $this->displayError($this->l('Property ID is required'));
            } else {
                \Configuration::updateValue('PERIPL_ENDPOINT', $endpoint);
                \Configuration::updateValue('PERIPL_PROPERTY_ID', $propertyId);

                // Mettre à jour les variables locales
                $this->endpoint = $endpoint;
                $this->propertyId = $propertyId;

                $output .= $this->displayConfirmation($this->l('Settings updated'));
            }
        }

        return $output . $this->renderForm();
    }

    protected function renderForm()
    {
        $fields_form = array(
            'form' => array(
                'legend' => array(
                    'title' => $this->l('Settings'),
                    'icon' => 'icon-cogs'
                ),
                'input' => array(
                    array(
                        'type' => 'text',
                        'label' => $this->l('API Endpoint URL'),
                        'name' => 'PERIPL_ENDPOINT',
                        'desc' => $this->l('The URL where tracking data will be sent'),
                        'required' => true
                    ),
                    array(
                        'type' => 'text',
                        'label' => $this->l('Property ID'),
                        'name' => 'PERIPL_PROPERTY_ID',
                        'desc' => $this->l('Your unique property identifier'),
                        'required' => true
                    )
                ),
                'submit' => array(
                    'title' => $this->l('Save'),
                    'class' => 'btn btn-default pull-right'
                )
            ),
        );

        $helper = new \HelperForm();
        $helper->show_toolbar = false;
        $helper->table = $this->table;
        $lang = new \Language((int)\Configuration::get('PS_LANG_DEFAULT'));
        $helper->default_form_language = $lang->id;
        $helper->allow_employee_form_lang = \Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG') ? \Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG') : 0;
        $helper->identifier = $this->identifier;
        $helper->submit_action = 'submit' . $this->name;
        $helper->currentIndex = $this->context->link->getAdminLink('AdminModules', false) . '&configure=' . $this->name . '&tab_module=' . $this->tab . '&module_name=' . $this->name;
        $helper->token = \Tools::getAdminTokenLite('AdminModules');
        $helper->tpl_vars = array(
            'fields_value' => array(
                'PERIPL_ENDPOINT' => \Configuration::get('PERIPL_ENDPOINT'),
                'PERIPL_PROPERTY_ID' => \Configuration::get('PERIPL_PROPERTY_ID')
            ),
            'languages' => $this->context->controller->getLanguages(),
            'id_language' => $this->context->language->id
        );

        return $helper->generateForm(array($fields_form));
    }

    /**
     * Hook exécuté très tôt dans le cycle de vie de la requête
     */
    public function hookActionDispatcher($params)
    {
        // Ce hook est l'un des premiers exécutés dans PrestaShop 1.6
        // Nous avons déjà enregistré notre fonction de shutdown dans le constructeur
        // Mais on pourrait faire des traitements supplémentaires ici si nécessaire
        return true;
    }

    /**
     * Hook dans l'en-tête HTML
     */
    public function hookDisplayHeader($params)
    {
        // On ne fait rien ici, notre tracking est déjà configuré dans le constructeur
        return '';
    }
}