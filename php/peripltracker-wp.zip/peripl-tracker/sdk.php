<?php

function periplSendDataFireAndForget($url, $data)
{
    $options = array(
        'http' => array(
            'method' => 'POST',
            'header' => 'Content-Type: application/json',
            'timeout' => 1,
            'ignore_errors' => true
        )
    );

    // Création du contexte
    $context = stream_context_create($options);

    // Envoi en mode fire & forget
    @file_get_contents($url . '?' . http_build_query($data), false, $context);
}

function periplSendTrackingBeforeShutdown($endpoint, $propertyId)
{
    // Vérifier si le module est actif et configuré
    if (empty($endpoint) || empty($propertyId)) {
        return;
    }

    // Récupération des informations depuis les variables serveur
    $host = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '';
    $uri = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';
    $url = $uri;

    // Construction de l'URL complète
    $pageFullUrl = 'https://' . $host . $uri;

    // Récupération du user agent
    $userAgent = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '';

    $bots = require(__DIR__ . '/bots.php');

    $botName = null;
    foreach ($bots as $bot => $details) {
        if (stripos($userAgent, $bot) !== false) {
            $botName = $details['name'];
            break;
        }
    }

    if ($botName === null) {
        return;
    }

    $statusCode = http_response_code();
    if (!$statusCode) {
        $statusCode = 200;
    }

    $data = array(
        'pu' => $pageFullUrl,
        'ua' => $userAgent,
        'et' => time(),
        'sc' => $statusCode,
        'prop' => $propertyId
    );

    periplSendDataFireAndForget($endpoint, $data);
}