<?php
/**
 * Plugin Name: Peripl Tracker
 * Plugin URI: https://peripl.com
 * Description: Tracks crawls from LLM.
 * Version: 1.0.0
 * Author: Glasses guys
 * Author URI: https://peripl.com
 * Text Domain: peripl-tracker
 * Requires at least: 4.0
 * Requires PHP: 5.6
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

class PeriplTracker {
    // Singleton instance
    private static $instance = null;

    // Plugin settings
    private $endpoint;
    private $propertyId;

    // Flag to check if plugin is properly configured
    private $is_configured = false;

    /**
     * Constructor
     */
    private function __construct() {
        // Load configuration
        $this->endpoint = get_option('peripl_tracker_endpoint', 'https://collector.peripl.com/crawl');
        $this->propertyId = get_option('peripl_tracker_property_id', '');

        // Check if plugin is properly configured
        $this->is_configured = $this->check_configuration();

        // Include the SDK only if properly configured
        if ($this->is_configured) {
            require_once(plugin_dir_path(__FILE__) . 'sdk.php');

            // Register the shutdown function only if configured
            register_shutdown_function('periplSendTrackingBeforeShutdown', $this->endpoint, $this->propertyId);
        }

        // Initialize hooks
        $this->init_hooks();
    }

    /**
     * Check if the plugin is properly configured
     */
    private function check_configuration() {
        $endpoint = get_option('peripl_tracker_endpoint', '');
        $property_id = get_option('peripl_tracker_property_id', '');

        // Check if endpoint is a valid URL
        $is_valid_endpoint = !empty($endpoint) && filter_var($endpoint, FILTER_VALIDATE_URL) !== false;

        // Check if property ID is set and not the default value
        $is_default_property_id = $property_id === 'PROPERTY_ID_DEFAULT';
        $is_valid_property_id = !empty($property_id);

        // Plugin is configured if both values are valid and not defaults
        return $is_valid_endpoint && $is_valid_property_id && !$is_default_property_id;
    }

    /**
     * Get singleton instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Initialize hooks
     */
    private function init_hooks() {
        // Register activation hook
        register_activation_hook(__FILE__, array($this, 'activate'));

        // Register deactivation hook
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));

        // Register uninstall hook - static method reference
        register_uninstall_hook(__FILE__, array('PeriplTracker', 'uninstall'));

        // Add admin menu
        add_action('admin_menu', array($this, 'add_admin_menu'));

        // Register settings
        add_action('admin_init', array($this, 'register_settings'));

        // Add activation redirect with high priority to ensure it runs early
        add_action('admin_init', array($this, 'activation_redirect'), 1);

        // Add admin notice if plugin is not configured
        if (!$this->is_configured) {
            add_action('admin_notices', array($this, 'admin_notice_configuration'));
        }
    }

    /**
     * Plugin activation
     */
    public function activate() {
        // Add default options if they don't exist
        if (false === get_option('peripl_tracker_endpoint')) {
            add_option('peripl_tracker_endpoint', 'https://api.example.com/endpoint');
        }

        if (false === get_option('peripl_tracker_property_id')) {
            add_option('peripl_tracker_property_id', 'PROPERTY_ID_DEFAULT');
        }

        // Set a transient with a unique name for this activation
        set_transient('peripl_tracker_activation_redirect', true, 30);
    }

    /**
     * Redirect to settings page after activation
     */
    public function activation_redirect() {
        // Check if we should redirect
        if (get_transient('peripl_tracker_activation_redirect')) {
            // Delete the transient first to prevent redirect loops
            delete_transient('peripl_tracker_activation_redirect');

            // Make sure we're not in network admin and not doing bulk activation
            if (!is_network_admin() && !isset($_GET['activate-multi'])) {
                // Add a small delay to ensure the transient is properly deleted
                wp_safe_redirect(admin_url('options-general.php?page=peripl-tracker'));
                exit;
            }
        }
    }

    /**
     * Admin notice for configuration
     */
    public function admin_notice_configuration() {
        // Don't show notice on the plugin's settings page
        $screen = get_current_screen();
        if ($screen->id === 'settings_page_peripl-tracker') {
            return;
        }

        ?>
        <div class="notice notice-warning is-dismissible">
            <p>
                <?php _e('Peripl Tracker is installed but not properly configured.', 'peripl-tracker'); ?>
                <a href="<?php echo admin_url('options-general.php?page=peripl-tracker'); ?>">
                    <?php _e('Configure now', 'peripl-tracker'); ?>
                </a>
            </p>
        </div>
        <?php
    }

    /**
     * Plugin deactivation
     */
    public function deactivate() {
        // We don't delete options on deactivation, only on uninstall
    }

    /**
     * Plugin uninstall
     */
    public static function uninstall() {
        // Delete options
        delete_option('peripl_tracker_endpoint');
        delete_option('peripl_tracker_property_id');
    }

    /**
     * Add admin menu
     */
    public function add_admin_menu() {
        add_options_page(
            __('Peripl Tracker Settings', 'peripl-tracker'),
            __('Peripl Tracker', 'peripl-tracker'),
            'manage_options',
            'peripl-tracker',
            array($this, 'settings_page')
        );
    }

    /**
     * Register settings
     */
    public function register_settings() {
        register_setting('peripl_tracker_settings', 'peripl_tracker_endpoint', array(
            'type' => 'string',
            'sanitize_callback' => array($this, 'validate_endpoint'),
            'default' => 'https://api.example.com/endpoint',
        ));

        register_setting('peripl_tracker_settings', 'peripl_tracker_property_id', array(
            'type' => 'string',
            'sanitize_callback' => 'sanitize_text_field',
            'default' => 'PROPERTY_ID_DEFAULT',
        ));

        add_settings_section(
            'peripl_tracker_main',
            __('Main Settings', 'peripl-tracker'),
            array($this, 'settings_section_callback'),
            'peripl-tracker'
        );

        add_settings_field(
            'peripl_tracker_endpoint',
            __('API Endpoint URL', 'peripl-tracker'),
            array($this, 'endpoint_field_callback'),
            'peripl-tracker',
            'peripl_tracker_main'
        );

        add_settings_field(
            'peripl_tracker_property_id',
            __('Property ID', 'peripl-tracker'),
            array($this, 'property_id_field_callback'),
            'peripl-tracker',
            'peripl_tracker_main'
        );
    }

    /**
     * Settings section callback
     */
    public function settings_section_callback() {
        echo '<p>' . __('Configure your Peripl Tracker settings below.', 'peripl-tracker') . '</p>';
    }

    /**
     * Endpoint field callback
     */
    public function endpoint_field_callback() {
        $endpoint = get_option('peripl_tracker_endpoint');
        echo '<input type="text" id="peripl_tracker_endpoint" name="peripl_tracker_endpoint" value="' . esc_attr($endpoint) . '" class="regular-text">';
        echo '<p class="description">' . __('The URL where tracking data will be sent', 'peripl-tracker') . '</p>';
    }

    /**
     * Property ID field callback
     */
    public function property_id_field_callback() {
        $property_id = get_option('peripl_tracker_property_id');
        echo '<input type="text" id="peripl_tracker_property_id" name="peripl_tracker_property_id" value="' . esc_attr($property_id) . '" class="regular-text">';
        echo '<p class="description">' . __('Your unique property identifier', 'peripl-tracker') . '</p>';
    }

    /**
     * Validate endpoint URL
     */
    public function validate_endpoint($input) {
        // Basic URL validation
        if (!empty($input) && filter_var($input, FILTER_VALIDATE_URL) === false) {
            add_settings_error(
                'peripl_tracker_endpoint',
                'peripl_tracker_endpoint_error',
                __('Invalid API endpoint URL', 'peripl-tracker'),
                'error'
            );
            return get_option('peripl_tracker_endpoint');
        }
        return $input;
    }

    /**
     * Settings page
     */
    public function settings_page() {
        // Check user capabilities
        if (!current_user_can('manage_options')) {
            return;
        }

        // Show settings form
        ?>
        <div class="wrap">
            <h1><?php echo esc_html(get_admin_page_title()); ?></h1>

            <?php
            // Show settings saved message if needed
            if (isset($_GET['settings-updated'])) {
                // Update local properties when settings are saved
                $this->endpoint = get_option('peripl_tracker_endpoint');
                $this->propertyId = get_option('peripl_tracker_property_id');

                // Re-check configuration status
                $this->is_configured = $this->check_configuration();

                $message = __('Settings saved.', 'peripl-tracker');

                // Add a message about configuration status
                if ($this->is_configured) {
                    $message .= ' ' . __('Peripl Tracker is now properly configured and active.', 'peripl-tracker');
                } else {
                    $message .= ' ' . __('Peripl Tracker is not yet properly configured. Please enter valid settings.', 'peripl-tracker');
                }

                add_settings_error(
                    'peripl_tracker_messages',
                    'peripl_tracker_message',
                    $message,
                    $this->is_configured ? 'updated' : 'warning'
                );
            }

            // Show error/update messages
            settings_errors('peripl_tracker_messages');

            // Show configuration status
            if (!$this->is_configured) {
                ?>
                <div class="notice notice-warning inline">
                    <p><?php _e('Tracking is currently disabled because the plugin is not properly configured. Please enter valid settings below and save changes.', 'peripl-tracker'); ?></p>
                </div>
                <?php
            } else {
                ?>
                <div class="notice notice-success inline">
                    <p><?php _e('Tracking is active and properly configured.', 'peripl-tracker'); ?></p>
                </div>
                <?php
            }
            ?>

            <form action="options.php" method="post">
                <?php
                settings_fields('peripl_tracker_settings');
                do_settings_sections('peripl-tracker');
                submit_button(__('Save Settings', 'peripl-tracker'));
                ?>
            </form>
        </div>
        <?php
    }
}

// Initialize the plugin
function peripl_tracker_init() {
    return PeriplTracker::get_instance();
}
add_action('plugins_loaded', 'peripl_tracker_init');

function peripl_activate_static() {
    peripl_tracker_init()->activate();
}

register_activation_hook(__FILE__, 'peripl_activate_static');